"""Atomic JSON model persistence, independent of application filesystem helpers."""

import os
import uuid
from pathlib import Path


class ArtifactLimitError(ValueError):
    """Raised when a document or consumer artifact exceeds its byte quota."""


def atomic_write_text(path: str | Path, content: str, encoding: str = "utf-8", *, max_bytes: int = 100 * 1024 * 1024) -> Path:
    target = Path(path)
    if len(content.encode(encoding)) > max_bytes:
        raise ArtifactLimitError(f"artifact quota exceeded ({max_bytes} bytes)")
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(f".{target.name}.{uuid.uuid4().hex}.partial")
    try:
        partial.write_text(content, encoding=encoding)
        os.replace(partial, target)
    finally:
        partial.unlink(missing_ok=True)
    return target
