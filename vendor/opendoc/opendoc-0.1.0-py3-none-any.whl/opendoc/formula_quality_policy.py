"""Budget changed or removed source formulas using reproducible fingerprints."""

import hashlib
import json
from collections import Counter
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from opendoc.diagnostics import ConversionReport, IssueSeverity
from opendoc.document_model import Formula, FormulaFormat
from opendoc.object_inventory import OBJECT_INVENTORY_SCOPE

if TYPE_CHECKING:
    from opendoc.inspection import DocumentComparison

FORMULA_FINGERPRINT_VERSION = "formula-native-tree-v1"


def formula_fingerprint(formula: Formula) -> str | None:
    """Compare supported MathML through OMML; preserve exact LaTeX source."""
    if not formula.value or len(formula.value.encode("utf-8")) > 1024 * 1024:
        return None
    if formula.format is FormulaFormat.LATEX:
        content = ["latex", formula.value]
    else:
        try:
            from lxml import etree

            value = formula.value
            if formula.format is FormulaFormat.MATHML:
                from opendoc.mathml import mathml_to_omml

                value = mathml_to_omml(value)
            root = etree.fromstring(value.encode("utf-8"), etree.XMLParser(resolve_entities=False, no_network=True))
            if root.getroottree().docinfo.doctype:
                return None
            nodes = list(root.iter())
            if len(nodes) > 4096 or any(len(list(node.iterancestors())) > 64 for node in nodes):
                return None
            namespace = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
            if root.tag == namespace + "oMathPara" and len(root) == 1:
                root = root[0]
            if root.tag != namespace + "oMath":
                return None
            content = ["omml", _tree(root)]
        except (ImportError, ValueError, TypeError, RecursionError, SyntaxError):
            return None
    return hashlib.sha256(json.dumps(content, ensure_ascii=False).encode("utf-8")).hexdigest()


def _tree(node: Any) -> list[Any]:
    """Namespace prefixes and XML indentation are not formula content."""
    text = node.text or ""
    if not text.strip() and node.tag.rsplit("}", 1)[-1] != "t":
        text = ""
    return [node.tag, sorted(node.attrib.items()), text, [_tree(child) for child in node if isinstance(child.tag, str)]]


@dataclass(frozen=True)
class FormulaLossPolicy:
    max_changed_formulas: int = 0

    def __post_init__(self) -> None:
        if type(self.max_changed_formulas) is not int or self.max_changed_formulas < 0:
            raise ValueError("max_changed_formulas must be a non-negative integer")

    def evaluate(self, report: ConversionReport, comparison: "DocumentComparison | None") -> bool:
        available = comparison is not None and comparison.valid
        counts = []
        for side in (comparison.source, comparison.target) if available else ():
            formulas = [item for item in side.objects if item.get("type") == "formula"]
            available = (
                available
                and side.metadata.get("object_inventory_scope") == OBJECT_INVENTORY_SCOPE
                and all(
                    item.get("formula_fingerprint_version") == FORMULA_FINGERPRINT_VERSION
                    and isinstance(item.get("formula_hash"), str)
                    for item in formulas
                )
            )
            counts.append(Counter(item.get("formula_hash") for item in formulas))
        changed = sum((counts[0] - counts[1]).values()) if available else None
        accepted = available and changed <= self.max_changed_formulas
        report.metrics["formula_quality_gate"] = {
            "basis": FORMULA_FINGERPRINT_VERSION,
            "verified": available,
            "accepted": accepted,
            "max_changed_formulas": self.max_changed_formulas,
            "changed_formulas": changed,
            "source_formulas": sum(counts[0].values()) if counts else None,
            "reason": "accepted" if accepted else "budget-exceeded" if available else "unavailable",
        }
        if not accepted:
            report.add(
                IssueSeverity.ERROR,
                "formula-quality",
                f"Несовпавших или удалённых формул: {changed}; допустимо: {self.max_changed_formulas}."
                if available
                else "Сохранность формул не удалось проверить: нет полного сопоставимого представления. Результат не выдан.",
            )
        return accepted
