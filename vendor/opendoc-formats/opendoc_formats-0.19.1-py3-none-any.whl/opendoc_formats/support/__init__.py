"""Format adapter implementation helpers."""
